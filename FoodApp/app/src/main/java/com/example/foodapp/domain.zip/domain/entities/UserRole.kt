package com.example.foodapp.domain.entities

enum class UserRole {
    BUYER,
    SELLER,
    SHIPPER
}
